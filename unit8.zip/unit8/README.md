
## Unit 8. Selected Collections. Generics

My solution to Unit8 of the training "Intro to Java and Java EE" taught by [Yakov Fain](https://github.com/yfain) from Farata Systems.

В этом уроке рассматривается: `Selected Collections, Generic types`.

### Links

[Video on Youtube](http://www.youtube.com/watch?v=Y6qi_6Q1b7o&list=UUnExw5tVdA3TJeb4kmCd-JQ) in Russian.

[All slides](https://code.google.com/p/practicaljava/wiki/Slides) of the course.
